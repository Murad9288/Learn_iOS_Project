//
//  ViewController.swift
//  Schedule_Loca_lNotifications
//
//  Created by Md Murad Hossain on 13/10/22.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var subtitleTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    let notificationCenter = UNUserNotificationCenter.current()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationReqestAutho()
        
        
    }
    
    func notificationReqestAutho() {
        notificationCenter.requestAuthorization(options: [.alert, .sound]) {
            (permissionInfo, error) in
            if !permissionInfo {
                print("Permission accepted")
            }
        }
    }

    @IBAction func scheduleDoneAction(_ sender: Any) {
        
        notificationCenter.getNotificationSettings { (settings) in
            DispatchQueue.main.async { [self] in
                let title = titleTextField.text!
                let message = subtitleTextField.text!
                let date = datePicker.date
                
                if settings.authorizationStatus == .authorized {
                    let content = UNMutableNotificationContent()
                    content.title = title
                    content.body = message
                    
                    let dateSetup = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
                    let tirgger = UNCalendarNotificationTrigger(dateMatching: dateSetup, repeats: false)
                    let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: tirgger)
                    notificationCenter.add(request) { (error) in
                        if error != nil {
                            print("Error " + error.debugDescription)
                            return
                        }
                    }
                    let alertContr = UIAlertController(title: "Notificate Scheduled", message: "At " + dateFormate(date), preferredStyle: .alert)
                    alertContr.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (_) in}))
                    present(alertContr,animated: true)
                    
                } else {
                    let alertContr = UIAlertController(title: "Enable Scheduled?", message: "To use this future you must enable notifications in settings", preferredStyle: .alert)
                    let gotoSettings = UIAlertAction(title: "Settings", style: .default) { (_) in
                        guard let settinsURL = URL(string: UIApplication.openSettingsURLString)
                        else {
                            return
                            
                        }
                        
                        if(UIApplication.shared.canOpenURL(settinsURL))
                        {
                            UIApplication.shared.open(settinsURL) { (_) in }
                        }
                    }
                    alertContr.addAction(gotoSettings)
                    alertContr.addAction(UIAlertAction(title: "Cancle", style: .default, handler: { (_) in}))
                    present(alertContr,animated: true)
                }
            }
        }
    }
    
    
    func dateFormate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d MMM y HH:mm"
        return formatter.string(from: date)
    }
    
}

