//
//  ViewController.swift
//  RealTimeDatabaseWithFirebase
//
//  Created by Md Murad Hossain on 14/2/23.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController {
    let ref = Database.database().reference()

    override func viewDidLoad() {
        super.viewDidLoad()
//        RealTimeDatabaseUpdate()
//       RealTimeDatabaseInsertData()
        RealTimeDatabaseShowData()
        RealTimeDatabaseDelete()
       
    }
    
    private func RealTimeDatabaseUpdate() {
        ref.child("101/Phone").setValue("01792889015")
    }
    
    private func RealTimeDatabaseInsertData() {
        ref.childByAutoId().setValue(["Name":"MD Abul Kashem","Age":" 30","Phone":"01299939442"])
    }
    
    private func RealTimeDatabaseShowData() {
        ref.child("101").observeSingleEvent(of: .value) { snapShot in
            let value = snapShot.value as? NSDictionary
            let name = value?["Name"] as? String
            print("Name : \(name!)")
        }
    }
    
    private func RealTimeDatabaseDelete() {
        ref.child("/-NOE9XyeK_0jWOFqN-d2").removeValue()
    }
}

